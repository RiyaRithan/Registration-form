import "./styles.css";
import { useState } from "react";

export default function App() {
  const [name, setName] = useState("");
  const [number, setNumber] = useState([]);
  const [dob, setDob] = useState([]);

  function main() {
    if (!name) {
      alert("Please Enter Name");
    }
    if (number.length < 10) {
      alert("Please Enter your conatct number");
    }
    if (number.length > 10) {
      alert("Thare are more than 10 digits");
    }
    if (!dob) {
      alert("Please enter the date of birth");
    }
    if (
      document.getElementById("name").value === name &&
      document.getElementById("number").value === number &&
      document.getElementById("dob").value === dob
    ) {
      alert("submitted successfully");
    }
  }

  return (
    <div>
      <h1>REGISTRATION FORM</h1>
      <form>
        <label>Name: </label>
        <input
          type="text"
          placeholder="Enter your name"
          value={name}
          id="name"
        ></input>
        <br />
        <br />
        <label>Phone number:</label>
        <input
          type="number"
          placeholder="Enter your phone number"
          value={"number"}
          id="number"
        ></input>
        <br />
        <br />
        <label>DOB:</label>
        <input
          type="number"
          placeholder="Enter the date of birth"
          value={"dob"}
          id="dob"
        ></input>
      </form>
    </div>
  );
}
